function [Fe, Je] = grad_hess_elastic_bilayer(q, c_time)

global Nedge numBendEl
global Edges 
global lk ks kb
global bendingElements flagVec


Fe = zeros(numel(q), 1);
Je = zeros(numel(q), numel(q));

%% stretching energy
for k=1:1:Nedge
%     fprintf("value of k: %d",k);
%     waitforbuttonpress
%     fprintf("Node0: %d",Edges(1,k));
%     waitforbuttonpress
    
    node0 = Edges(1,k); %first node
    x0 = transpose(q(3*node0-2:3*node0));
    
    node1 = Edges(2,k); %second node
    x1 = transpose(q(3*node1-2:3*node1));
    
    ind = [3*node0-2, 3*node0-1, 3*node0, 3*node1-2, 3*node1-1, 3*node1];
        
    [dF, dJ] = gradEs_hessEs_Shell(x0, x1, lk(k), ks(k));
    Fe(ind) = Fe(ind) + dF;
    Je(ind,ind) = Je(ind,ind) + dJ;
    
    
end

%% bending energy
for h=1:1:numBendEl
    bnode0 = bendingElements(1,h);
    x0 = q(3*bnode0-2 : 3*bnode0);
    
    bnode1 = bendingElements(2,h);
    x1 = q(3*bnode1-2 : 3*bnode1);
    
    bnode2 = bendingElements(3,h);
    x2 = q(3*bnode2-2 : 3*bnode2);
    
    bnode3 = bendingElements(4,h);
    x3 = q(3*bnode3-2 : 3*bnode3);
    
    ind = [3*bnode0-2, 3*bnode0-1, 3*bnode0, ...
           3*bnode1-2, 3*bnode1-1, 3*bnode1, ...
           3*bnode2-2, 3*bnode2-1, 3*bnode2, ...
           3*bnode3-2, 3*bnode3-1, 3*bnode3 ];
       
    theta_bar = computeThetaBar(x0, x1, x2, x3, flagVec(h), c_time, h);
           
    [dF, dJ] = gradEb_hessEb_Shell(x0,x1,x2,x3,theta_bar,kb(flagVec(h)+1));
    
    Fe(ind) = Fe(ind) + dF;
    Je(ind,ind) = Je(ind,ind) + dJ;
end

end