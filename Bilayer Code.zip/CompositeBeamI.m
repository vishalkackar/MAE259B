function It = CompositeBeamI(Ek, Es, tk, ts)
%Returns the effective I of the kirigami and substrate layers per unit
%width.
%Takes in the Young's Moduli and the thicknesses of the two layers

n = Ek/Es;

yk_bar = tk/2;
ys_bar = tk + ts/2;

%w cancels out when finding y_bar 
y_bar = (n*tk*yk_bar + ts*ys_bar)/(n*tk + ts);

%I per width
Ik = n*(1/12*tk^3 + tk*abs(y_bar-yk_bar)^2);
Is = 1/12*ts^3 + ts*abs(ys_bar-yk_bar)^2;

% per unit width (should cancel out later on, so no need for width)
It = Ik + Is;

end