function thetaBarInfinity = findTBarInfinity(bendingElements, Nodes)

global kb lambda Ys ts

[~, numBendEl] = size(bendingElements);

thetaBarInfinity = zeros(1, numBendEl);

for k=1:1:numBendEl
    x0 = Nodes(:,bendingElements(1,k));
    x1 = Nodes(:,bendingElements(2,k));
    
    lk = norm(x1-x0);
    ks = 1/2 * sqrt(3) * Ys * ts * lk^2;
    
    E_init = ks*(lambda-1)^2;
    thetaBarInfinity(k) = sqrt( 2*E_init/kb(2) );
    
end

end