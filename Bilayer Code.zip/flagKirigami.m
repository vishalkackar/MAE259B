function flagVec = flagKirigami(cutOutElements, ElementToNode, bendingElements)

sizeCOE = length(cutOutElements);

flagElements = zeros(3, sizeCOE);
for k = 1:sizeCOE
    tempindex = cutOutElements(k);
    flagElements(1, k) = ElementToNode(1, tempindex);
    flagElements(2, k) = ElementToNode(2, tempindex);
    flagElements(3, k) = ElementToNode(3, tempindex);
end

[~, BEcols] = size(bendingElements);
flagVec = zeros(1, BEcols);

for j = 1:sizeCOE
    val1 = flagElements(1, j);
    val2 = flagElements(2, j);
    val3 = flagElements(3, j);
    
    for i = 1:BEcols
        if val1 == bendingElements(1, i) || val1 == bendingElements(2, i) ...
                || val1 == bendingElements(3, i) || val1 == bendingElements(4, i)
            
            if val2 == bendingElements(1, i) || val2 == bendingElements(2, i) ...
                || val2 == bendingElements(3, i) || val2 == bendingElements(4, i)
            
                if val3 == bendingElements(1, i) || val3 == bendingElements(2, i) ...
                || val3 == bendingElements(3, i) || val3 == bendingElements(4, i)
                    flagVec(i) = 1;
            
                end
            end
            
        end
        
        
    end
    
    
    
end











end