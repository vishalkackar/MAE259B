function thetaBar = computeThetaBar(x0, x1, x2, x3, flag, c_time, k)

global bc_time thetaBarInf
global maxMeshSize 

thetaBarGlobal = thetaBarInf(k);

% add negative or positive direction calculation

x2(3) = x2(3) - maxMeshSize/100;
x3(3) = x3(3) - maxMeshSize/100;

ang = getTheta(x0, x1, x2, x3);

if ang < 0
    thetaBarGlobal = -thetaBarGlobal;
end


% need to also slowly step theta 
if c_time <= bc_time
    thetaBarGlobal = thetaBarGlobal * c_time/bc_time;
end

thetaBar = thetaBarGlobal * flag;

end