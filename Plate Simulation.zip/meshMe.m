function [Nodes, Edges, ElementToNode, ElementToEdge, bendingElements] = meshMe(l, w)

%% Create the mesh
maxMeshSize = w/3;
minMeshSize = maxMeshSize/2;

gd = [3; 4; 0; l; l; 0; 0; 0; w; w];
g = decsg(gd);
model = createpde;
geometryFromEdges(model,g);

FEMesh = generateMesh(model, 'Hmax', maxMeshSize, 'Hmin', ...
    minMeshSize, 'GeometricOrder', 'linear');

%% contains the indices of three edges for the c-th element
ElementToNode = FEMesh.Elements;
Nodes = FEMesh.Nodes;
[~, numNodes] = size(FEMesh.Nodes);
[~, numElements] = size(FEMesh.Elements);

% Convert 2xN matrix to 3xN matrix
Nodes = [Nodes; zeros(1, numNodes)];

ElementToEdge = zeros(3, numElements);
Edges = zeros( 2, 3 * numElements); % large enough container

numEdges = 0;
for cEl = 1 : numElements
    
    node1 = min( ElementToNode(:, cEl) );
    node2 = median( ElementToNode(:, cEl) );
    node3 = max( ElementToNode(:, cEl) );
    
    % Go over the three edges and add to "Edges" matrix if necessary
    ind = find( Edges(1,:) == node1 & Edges(2,:) == node2 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node1;
        Edges( 2, numEdges ) = node2;
        
        edge1_no = numEdges;
    elseif numel(ind) == 1
        edge1_no = ind;
    else
        disp('Error in edge 1 location');
    end
    
    ind = find( Edges(1,:) == node2 & Edges(2,:) == node3 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node2;
        Edges( 2, numEdges ) = node3;
        
        edge2_no = numEdges;
    elseif numel(ind) == 1
        edge2_no = ind;
    else
        disp('Error in edge 2 location');
    end
    
    ind = find( Edges(1,:) == node1 & Edges(2,:) == node3 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node1;
        Edges( 2, numEdges ) = node3;
        
        edge3_no = numEdges;
    elseif numel(ind) == 1
        edge3_no = ind;
    else
        disp('Error in edge 3 location');
    end
    
    ElementToEdge( 1, cEl ) = min( [edge1_no edge2_no edge3_no] );
    ElementToEdge( 2, cEl ) = median( [edge1_no edge2_no edge3_no] );
    ElementToEdge( 3, cEl ) = max( [edge1_no edge2_no edge3_no] );
end

Edges = Edges( :, 1:numEdges);

%% Bending Elements
bendingElements = zeros(4, numEdges);

numBendElements = 0;
for c=1:numEdges
    
    % Find the two triangular elements that share this edge
    ind = find( ElementToEdge(:) == c );
    if numel(ind) == 1
        % fprintf('Edge %d is on the boundary\n', c);
    elseif numel(ind) == 2
        n0 = Edges(1, c);
        n1 = Edges(2, c);
        
        El_1 = ceil( ind(1) / 3 ); % Triangle 1 that includes edge no. c
        El_2 = ceil( ind(2) / 3 ); % Triangle 2 that includes edge no. c
        
        El_1_nodes = ElementToNode(:, El_1);
        El_2_nodes = ElementToNode(:, El_2);
        
        n2 = El_1_nodes( El_1_nodes~=n0 & El_1_nodes~=n1 );
        n3 = El_2_nodes( El_2_nodes~=n0 & El_2_nodes~=n1 );
        
        %
        % Locations of nodes
        %
        x0 = Nodes(:, n0);
        x1 = Nodes(:, n1);
        x2 = Nodes(:, n2);
        x3 = Nodes(:, n3);
        
        %
        % Is the ordering correct?
        %
        m_e0 = x1 - x0;
        m_e1 = x2 - x0;
        m_e2 = x3 - x0;
        norm0 = cross(m_e0, m_e1); % Normal on face 0
        norm1 = cross(m_e2, m_e0); % Normal on face 1
        component = dot(m_e0, cross(norm0, norm1)); % This must be positive
        if component < 0 % If negative, switch x2 and x3
            temp = n2;
            n2 = n3;
            n3 = temp;
        end
        
        % Store in the container
        numBendElements = numBendElements + 1;
        bendingElements(1, numBendElements) = n0;
        bendingElements(2, numBendElements) = n1;
        bendingElements(3, numBendElements) = n2;
        bendingElements(4, numBendElements) = n3;
        
    else
        disp('Error in finding bending elements');
    end    
end

bendingElements = bendingElements(:, 1:numBendElements);
end