function [F, J] = grad_hess_elastic(q)

global Nedge Nhinge
global Edges bendingElements
global lk ks
global theta_bar kb

F = zeros(numel(q), 1);
J = zeros(numel(q), numel(q));

for e=1:1:Nedge
    ind1 = Edges(1,e);
    x0 = q(ind1*3-2 : ind1*3);
    ind2 = Edges(2,e);
    x1 = q(ind2*3-2 : ind2*3);
    
    ind = [3*ind1-2, 3*ind1-1, 3*ind1, 3*ind2-2, 3*ind2-1, 3*ind2];
    
    [dF, dJ] = gradEs_hessEs_Shell(x0, x1, lk(e), ks(e));
    
    F(ind) = F(ind) + dF;
    J(ind,ind) = J(ind,ind) + dJ;
    
end

for h=1:1:Nhinge
    x0 = q(3*bendingElements(1,h)-2:3*bendingElements(1,h));
    x1 = q(3*bendingElements(2,h)-2:3*bendingElements(2,h));
    x2 = q(3*bendingElements(3,h)-2:3*bendingElements(3,h));
    x3 = q(3*bendingElements(4,h)-2:3*bendingElements(4,h));
    
    ind = [3*bendingElements(1,h)-2, 3*bendingElements(1,h)-1, 3*bendingElements(1,h), ...
           3*bendingElements(2,h)-2, 3*bendingElements(2,h)-1, 3*bendingElements(2,h), ...
           3*bendingElements(3,h)-2, 3*bendingElements(3,h)-1, 3*bendingElements(3,h), ...
           3*bendingElements(4,h)-2, 3*bendingElements(4,h)-1, 3*bendingElements(4,h)];
       
    [dF, dJ] = gradEb_hessEb_Shell(x0,x1,x2,x3,theta_bar,kb);
    
    F(ind) = F(ind) + dF;
    J(ind,ind) = J(ind,ind) + dJ;
end


end