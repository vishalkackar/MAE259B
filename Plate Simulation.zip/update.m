function [qnew, vnew] = update(qold, vold)

global maxIter tol consInd
global mass weight massMat
global dt

qnew = qold;
iter = 1;

error = 10*tol;

while (error > tol && iter < maxIter)
    [F, J] = grad_hess_elastic(qnew);
    
    f = mass.*(qnew-qold)/dt^2 - mass.*vold/dt - (F + weight);
    j = massMat/dt^2 - J;
    
    qnew = qnew - j\f;
    
    for i=1:1:length(consInd)
        qnew(3*consInd(i)-2:3*consInd(i)) = qold(3*consInd(i)-2:3*consInd(i));
    end
    
    fprintf("(%f,%f,%f) (%f,%f,%f)\n",qnew(1),qnew(2),qnew(3),qnew(22),qnew(23),qnew(24));
    
    error = sum(abs(f));
    
    fprintf("Error: %f | ",error)
    
    
    iter = iter + 1;
    fprintf("Iteration number: %d\n",iter)
    
    waitforbuttonpress
end

vnew = (qnew-qold)/dt;

end