%% Beam model deflection - ch 8 hw 2
clc; clear all; close all;

%% Globals

global EA EI dL nodes
global maxIter tol
global freeInd
global mass dt massMat weight
global visc

%% Parameters

L = 0.1;
w = 0.01;
h = 0.002;

Y = 10^7;
rho = 1000;
EA = Y * w*h;
EI = Y * (w^3) * h / 12;
visc = 0;

t0 = 0;
tf = 5;
dt = 0.001;
steps = (tf-t0)/dt;

nodes = 51;
edges = nodes-1;
dL = L/edges;

maxIter = 100;
tol = 1e-6;

%% set up relevant quantities

q = zeros(2*nodes, 1);
v = zeros(2*nodes, 1);

for i=1:1:nodes
    q(2*i-1) = dL * (i-1);
end

x = q(1:2:end);
y = q(2:2:end);

figure(1)
plot(x,y,'ro-')
axis equal
title("Initial beam configuration")
xlabel("x position [m]")
ylabel("y position [m]")

totmass = L*w*h*rho;
edgemass = totmass/edges;

mass = zeros(2*nodes, 1) + edgemass;
mass(1:2) = edgemass/2;
mass(2*nodes-1:2*nodes) = edgemass/2;
massMat = diag(mass);

weight = zeros(2*nodes, 1);
weight(2:2:end) = mass(2:2:end) * -9.81;

freeInd = [5:1:2*nodes];

%% update function
% 
% for i=1:1:2
%     [q2,v2] = update_beam(q,v)
%     q = q2;
%     v = v2;
% end

for t=1:1:steps
%     fprintf("\n\nTime = %f\n", dt*t);
    [q2,v2] = update_beam(q,v);
    
    q = q2;
    v = v2;
    
end

x = q(1:2:end);
y = q(2:2:end);

figure(2)
plot(x,y,'bo-')
axis equal
title("Final beam configuration")
xlabel("x position [m]")
ylabel("y position [m]")

