function [qnew, vnew] = update_beam(qold, vold)

global maxIter tol
global freeInd
global mass dt massMat weight
global visc dL nodes

qnew = qold;

error = 10*tol;
iter = 1;

while (error > tol && iter <= maxIter)
    [Fs, Js] = stretchFunc(qnew);
    [Fb, Jb] = bendFunc(qnew);
    
    Fv = -visc * dL * (qnew-qold)/dt;
    Jv = -visc * dL / dt * eye(2*nodes, 2*nodes);
    
    f = mass.*(qnew-qold)/dt^2 - mass.*vold/dt + Fs + Fb - (weight+Fv);
    J = massMat/dt^2 + Js + Jb - Jv;
    
    f_free = f(freeInd);
    J_free = J(freeInd,freeInd);
    
    dq_free = J_free\f_free;
    qnew(freeInd) = qnew(freeInd) - dq_free;
    
    error = sum(abs(f_free));
%     fprintf("Error: %f | ",error)
%     fprintf("Iteration number: %d\n",iter)
    %waitforbuttonpress
    iter = iter+1;
    
end

vnew = (qnew - qold)/dt;

end