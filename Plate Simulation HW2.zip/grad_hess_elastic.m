function [F, J] = grad_hess_elastic(q)

global Nedge Nhinge
global Edges bendingElements
global lk ks
global theta_bar kb

F = zeros(numel(q), 1);
J = zeros(numel(q), numel(q));

%stretching energy
for e=1:1:Nedge
    
    %get the first node in the edge
    node1 = Edges(1,e);
    x0 = transpose(q(node1*3-2 : node1*3));
    %get the second node in the edge
    node2 = Edges(2,e);
    x1 = transpose(q(node2*3-2 : node2*3));
    
    ind = [3*node1-2, 3*node1-1, 3*node1, 3*node2-2, 3*node2-1, 3*node2];
    
    [dF, dJ] = gradEs_hessEs_Shell(x0, x1, lk(e), ks(e));
    
    F(ind) = F(ind) + dF;
    J(ind,ind) = J(ind,ind) + dJ;
    
%     F(3*ind1-2:3*ind1) = F(3*ind1-2:3*ind1) + dF(1:3);
%     F(3*ind2-2:3*ind2) = F(3*ind2-2:3*ind2) + dF(4:6);
%     
%     J(3*ind1-2:3*ind1,3*ind1-2:3*ind1) = J(3*ind1-2:3*ind1,3*ind1-2:3*ind1) + dJ(1:3,1:3);
%     J(3*ind2-2:3*ind2,3*ind2-2:3*ind2) = J(3*ind2-2:3*ind2,3*ind2-2:3*ind2) + dJ(4:6,4:6);
    
end

%bending energy
for h=1:1:Nhinge
    bnode0 = bendingElements(1,h);
    x0 = q(3*bnode0-2 : 3*bnode0);
    
    bnode1 = bendingElements(2,h);
    x1 = q(3*bnode1-2 : 3*bnode1);
    
    bnode2 = bendingElements(3,h);
    x2 = q(3*bnode2-2 : 3*bnode2);
    
    bnode3 = bendingElements(4,h);
    x3 = q(3*bnode3-2 : 3*bnode3);
    
    ind = [3*bnode0-2, 3*bnode0-1, 3*bnode0, ...
           3*bnode1-2, 3*bnode1-1, 3*bnode1, ...
           3*bnode2-2, 3*bnode2-1, 3*bnode2, ...
           3*bnode3-2, 3*bnode3-1, 3*bnode3 ];
       
    [dF, dJ] = gradEb_hessEb_Shell(x0,x1,x2,x3,theta_bar,kb);
    
    F(ind) = F(ind) + dF;
    J(ind,ind) = J(ind,ind) + dJ;
end

end