function [qnew, vnew] = update(qold, vold)

global maxIter tol freeInd fixInd
global mass weight massMat
global dt visc viscLen len

qnew = qold;
iter = 1;

error = 10*tol;

while (error > tol && iter <= maxIter)
    
    [F, J] = grad_hess_elastic(qnew);
    
    %viscous drag
    fv = -visc * (qnew-qold)/dt * viscLen;
    jv = -visc * viscLen / dt * eye(3*len,3*len);
    
    f = mass.*(qnew-qold)/dt^2 - mass.*vold/dt + F - weight - fv;
    j = massMat/dt^2 + J - jv;
    
    f_free = f(freeInd);
    j_free = j(freeInd,freeInd);
    dq_free = j_free\f_free;
    
    qnew(freeInd) = qnew(freeInd) - dq_free;
    %qnew(fixInd) = qold(fixInd);
    
    error = sum(abs(f_free));
    
    fprintf("Error: %f | ",error)
    fprintf("Iteration number: %d\n",iter)
    iter = iter + 1;
    
end

vnew = (qnew-qold)/dt;

end