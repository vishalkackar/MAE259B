%% Chapter 8 Assignment
clc; clear all; close all;

%% Globals
global Nedge Nhinge freeInd fixInd
global len visc viscLen
global Edges bendingElements
global lk ks
global theta_bar kb
global maxIter tol 
global mass weight massMat
global dt

%% Parameters

l = 0.1;
w = 0.01;
h = 0.002;

Y = 10^7;
rho = 1000;
visc = 2; %to make sure simulation converges

theta_bar = 0; %natural curvature

kb = 2/sqrt(3) * Y *(h^3)/12;

maxIter = 100;
tol = 1e-6;

t0 = 0;
tf = 2;
dt = 0.001;
%% Create the mesh and the relevant info
[Nodes, Edges, ElementToNode, ElementToEdge, bendingElements] = meshMe(l, w);

[~, Nedge] = size(Edges);
[~, Nhinge] = size(bendingElements);
[~, len] = size(Nodes);

q = zeros(numel(Nodes), 1);
v = zeros(length(q),1);

% "flatten" out Nodes to create q
for i=1:1:len
    q(3*i-2:3*i) = Nodes(:,i);
end
 
%% calculate lk and ks
lk = zeros(1,numel(Edges)/2);

for i=1:1:numel(lk)
    node1 = Nodes(:,Edges(1,i));
    node2 = Nodes(:,Edges(2,i));
    lk(i) = norm(node2 - node1);
end

%length that the viscous forces act on
viscLen = mean(lk);

ks = 1/2 * sqrt(3) * Y * h *lk.^2;

%% TEMP mass of each node
totalMass = rho*w*l*h;

mass = zeros(len*3,1) + totalMass/len;
massMat = diag(mass);

%% TEMP weight (includes gravity)
weight = mass;
weight(1:3:end) = 0;
weight(2:3:end) = 0;
weight(3:3:end) = weight(3:3:end) * -9.81;

%% find unconstrained nodes

consInd = zeros(len,1);
counter = 1;
for i=1:1:Nedge
    %the indices of the nodes that define an edge
    node1 = Edges(1,i);
    node2 = Edges(2,i);
    
    %if the x value of a node is 0
    zero = Nodes(1,node1) == 0 || Nodes(1,node2) == 0;
    
    if(zero)
        %if zero, then add that node and what it's connected to (Edge)
        consInd(counter: counter+1) = Edges(:,i);
        counter = counter + 2;
    end
end

%take the unique values and get rid of 0
consInd = unique(consInd);
consInd = consInd(2:end);

fixInd = [1:1:3*length(consInd)];
for i=1:1:length(consInd)
    fixInd(3*i-2) = 3*consInd(i)-2;
    fixInd(3*i-1) = 3*consInd(i)-1;
    fixInd(3*i) = 3*consInd(i);
end
transpose(fixInd);

temp = [1:1:len];
temp(consInd) = 0;

unconsInd = find(temp ~= 0);
freeInd = zeros(3*numel(unconsInd),1);
transpose(unconsInd);

for i=1:1:length(unconsInd)
    freeInd(3*i-2) = 3*unconsInd(i)-2;
    freeInd(3*i-1) = 3*unconsInd(i)-1;
    freeInd(3*i) = 3*unconsInd(i);
    
end

%% run the simulation using the update function

steps = (tf-t0)/dt;

for t=1:1:steps
    fprintf("\n\nTime = %f\n", dt*t);
    [q2,v2] = update(q,v);
    xn = q2(1:3:end);
    yn = q2(2:3:end);
    zn = q2(3:3:end);
    
%     xlength = length(xn)
%     ylength = length(yn)
%     zlength = length(zn)
    

    figure(1)
    hold on
    clf;
    plot3(xn,yn,zn,'ro')
%     waitforbuttonpress
    
    q = q2;
    v = v2;
    
end

hold off

