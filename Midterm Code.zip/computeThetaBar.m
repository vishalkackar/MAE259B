function thetaBar = computeThetaBar(node0, node1, ks, flag)

global kb lambda

%stretching energy
E_init = ks * (lambda-1)^2;
thetaBarGlobal = sqrt( E_init/kb(2) );

%find the direction of the edge vector
edgeVec = node1 - node0;
unitEdge = edgeVec/norm(edgeVec);

%since radial stretching, lambda vec is always in the 1,1 direction
unitLambda = [1;1;0] * sqrt(2);
transpose(unitLambda);

d = abs(dot(unitEdge, unitLambda)); % d = [0,1]
%0 = perpendicular = full theta
%1 = parallel = no theta

thetaBar = (1 - d) * thetaBarGlobal * flag;

end