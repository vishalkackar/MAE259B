function [qnew, vnew] = BilayerUpdate(qold, vold)

global freeInd
global maxIter tol
global dt massMat mass weight
global visc viscLen

%first guess
qnew = qold;
len = numel(qold);

iter = 1;
error = 10*tol;

while (error > tol && iter <= maxIter)
    [F, J] = grad_hess_elastic_bilayer(qnew);
    
    %viscous drag
    fv = -visc * (qnew-qold)/dt * viscLen;
    jv = -visc * viscLen / dt * eye(len,len);
    
%     fprintf("F: %d\n", numel(F))
%     fprintf("mass: %d\n",numel(mass))
%     fprintf("qnew: %d\n",numel(qnew))
%     fprintf("qold: %d\n",numel(qold))
%     fprintf("vold: %d\n",numel(vold))
%     fprintf("weight: %d\n",numel(weight))
%     fprintf("fv: %d\n",numel(fv))
%     waitforbuttonpress

    f = mass.*(qnew-qold)/dt^2 - mass.*vold/dt + F - weight - fv;
    j = massMat/dt^2 + J - jv;
    

    
    f_free = f(freeInd);
    j_free = j(freeInd,freeInd);
    dq_free = j_free\f_free;
    
    qnew(freeInd) = qnew(freeInd) - dq_free;
    
    error = sum(abs(f_free));
    
    fprintf("Error: %f | ",error)
    fprintf("Iteration number: %d\n",iter)
    iter = iter + 1;
    
end

vnew = (qnew - qold) / dt;

end