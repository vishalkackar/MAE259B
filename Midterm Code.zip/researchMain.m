%% Research Main 
clc; clear all; close all;

%% globals
global kb dt
global flagVec bendingElements Edges
global maxIter tol
global Nedge numBendEl
global lk ks Ys
global lambda freeInd
global massMat mass weight
global visc viscLen
global thetaBar It

%% parameters

rho = 800; %density

Yk = 1000e3; %kirigami
%Ys = 750;
Ys = 690e3; %substrate
tk = 0.001;
ts = 0.001;

%lambda x = lambda y
% lambdax = [1; 0];
% lambday = [0; 1];
% lambda = lambdax + lambday;
% lambdaNorm = norm(lambda);
lambda = 1.1;

% no stretch lambdaNorm = 1.4
It = CompositeBeamI(Yk,Ys,tk,ts);

%to account for thickness decreasing b/c of stretch
kb = zeros(2,1);
kb(1) = 2/sqrt(3) * Ys * ts^3 / 12; % bending stiffness of substrate
kb(2) = 2/sqrt(3) * Ys * It; % bending stiffness of special region

%simulation time, have 1.5 extra seconds
t0 = 0;
dt = 0.01;
tf = 3.5;
steps = (tf-t0)/dt+1;

t_bc = 2; % have l_bar reach l_inf after 2 seconds

maxIter = 100;
tol = 1e-6;

visc = 2;

%% create mesh

innerRadius = 0.1;
outerRadius = 0.2;
Nstrips = 8;
dTheta = 0.3;
maxMeshSize = innerRadius / 5;
minMeshSize = maxMeshSize / 2;

[FEMesh, cutOutElements] = cutoutMesh_v4(innerRadius, outerRadius, ...
    Nstrips, dTheta, ...
    maxMeshSize, minMeshSize);


ElementToNode = FEMesh.Elements;
Nodes = FEMesh.Nodes;

[~, numNodes] = size(Nodes);
[~, numElements] = size(ElementToNode);

Nodes = [Nodes; zeros(1,numNodes)]; %3D version of the node matrix

%% Get the unique edges
ElementToEdge = zeros(3, numElements);
Edges = zeros( 2, 3 * numElements); % large enough container

numEdges = 0;
for cEl = 1 : numElements
    
    node1 = min( ElementToNode(:, cEl) );
    node2 = median( ElementToNode(:, cEl) );
    node3 = max( ElementToNode(:, cEl) );
    
    % Go over the three edges and add to "Edges" matrix if necessary
    ind = find( Edges(1,:) == node1 & Edges(2,:) == node2 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node1;
        Edges( 2, numEdges ) = node2;
        
        edge1_no = numEdges;
    elseif numel(ind) == 1
        edge1_no = ind;
    else
        disp('Error in edge 1 location');
    end
    
    ind = find( Edges(1,:) == node2 & Edges(2,:) == node3 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node2;
        Edges( 2, numEdges ) = node3;
        
        edge2_no = numEdges;
    elseif numel(ind) == 1
        edge2_no = ind;
    else
        disp('Error in edge 2 location');
    end
    
    ind = find( Edges(1,:) == node1 & Edges(2,:) == node3 );
    if numel(ind) == 0
        numEdges = numEdges + 1;
        Edges( 1, numEdges ) = node1;
        Edges( 2, numEdges ) = node3;
        
        edge3_no = numEdges;
    elseif numel(ind) == 1
        edge3_no = ind;
    else
        disp('Error in edge 3 location');
    end
    
    ElementToEdge( 1, cEl ) = min( [edge1_no edge2_no edge3_no] );
    ElementToEdge( 2, cEl ) = median( [edge1_no edge2_no edge3_no] );
    ElementToEdge( 3, cEl ) = max( [edge1_no edge2_no edge3_no] );
end

Edges = Edges( :, 1:numEdges);
[~, Nedge] = size(Edges);
%% Bending Elements

bendingElements = zeros(4, numEdges);

cutBendElementsInd = zeros(numel(cutOutElements), 1);
cutInd = 1;

numBendElements = 0;
for c=1:numEdges
    
    % Find the two triangular elements that share this edge
    ind = find( ElementToEdge(:) == c );
    if numel(ind) == 1
        % fprintf('Edge %d is on the boundary\n', c);
    elseif numel(ind) == 2
        n0 = Edges(1, c);
        n1 = Edges(2, c);
        
        El_1 = ceil( ind(1) / 3 ); % Triangle 1 that includes edge no. c
        El_2 = ceil( ind(2) / 3 ); % Triangle 2 that includes edge no. c
        
        %waitforbuttonpress
        
        El_1_nodes = ElementToNode(:, El_1);
        El_2_nodes = ElementToNode(:, El_2);
        
        n2 = El_1_nodes( El_1_nodes~=n0 & El_1_nodes~=n1 );
        n3 = El_2_nodes( El_2_nodes~=n0 & El_2_nodes~=n1 );
        
        %
        % Locations of nodes
        %
        x0 = Nodes(:, n0);
        x1 = Nodes(:, n1);
        x2 = Nodes(:, n2);
        x3 = Nodes(:, n3);
        
        %
        % Is the ordering correct?
        %
        m_e0 = x1 - x0;
        m_e1 = x2 - x0;
        m_e2 = x3 - x0;
        norm0 = cross(m_e0, m_e1); % Normal on face 0
        norm1 = cross(m_e2, m_e0); % Normal on face 1
        component = dot(m_e0, cross(norm0, norm1)); % This must be positive
        if component < 0 % If negative, switch x2 and x3
            temp = n2;
            n2 = n3;
            n3 = temp;
        end
        
        % Store in the container
        numBendElements = numBendElements + 1;
        bendingElements(1, numBendElements) = n0;
        bendingElements(2, numBendElements) = n1;
        bendingElements(3, numBendElements) = n2;
        bendingElements(4, numBendElements) = n3;
        
    else
        disp('Error in finding bending elements');
    end    
end

bendingElements = bendingElements(:, 1:numBendElements);
[~, numBendEl] = size(bendingElements);

%% create the flag vector for kirigami regions
flagVec = flagKirigami(cutOutElements, ElementToNode, bendingElements);

%% Plotting the figure
figure(1);
hold on
for c=1:numElements
    positions = FEMesh.Nodes(:, FEMesh.Elements(:,c));
    x = positions(1,:);
    y = positions(2,:);
    x = [x x(1)];
    y = [y y(1)];
    p1 = plot(x, y, 'r-');
end

NKirigami = numel(cutOutElements);
for c=1:NKirigami
    elemenet_no = cutOutElements(c);
    positions = FEMesh.Nodes(:, FEMesh.Elements(:,elemenet_no));
    x = positions(1,:);
    y = positions(2,:);
    x = [x x(1)];
    y = [y y(1)];
    plot(x, y, 'k--', 'LineWidth', 2);
end

hold off
axis equal
box on

%% mass and weight and q and v

q = zeros(numNodes*3,1);
v = q;
mass = q;

totalMass = rho * pi* outerRadius^2 * (ts/lambda+tk);
massPerNode = totalMass/numNodes;

for i=1:1:numNodes
    mass(3*i-2:3*i) = massPerNode;
end

massMat = diag(mass);

for k=1:1:numNodes
    q(3*k-2) = Nodes(1,k);
    q(3*k-1) = Nodes(2,k);
    
end

freeInd = [10:1:numel(q)];
weight = mass;

weight(1:3:end) = 0;
weight(2:3:end) = 0;
weight(3:3:end) = -9.81 * mass(3:3:end);

%% reference length calculation

lk_0 = zeros(1,numel(Edges)/2);

for i=1:1:numel(lk_0)
    node1 = Nodes(:,Edges(1,i));
    node2 = Nodes(:,Edges(2,i));
   
    % starts as lk = full stretch and slowly decrease it to l_inf
    
    lk_0(i) = norm(node2 - node1); % to account for the stretch
end

lk_inf = lk_0/lambda;
% for bidirectional stretching
%use a linear ramp function to step from l_bar to l_bar_infinity
%calculate l_inf once and calc l_bar at each time step

%ks changes with time as well -> changs with l_bar
%thickness also changing with time, nu = 1/2, changes by lambda each iter
ks = 1/2 * sqrt(3) * Ys * ts * lk_0.^2; %stretching stiffness

%% iterations

for i=1:1:steps
    %to slowly ramp lk from lk_0 down to lk_inf
    if(dt*(i-1) == t_bc)
        lk = lk_0 - (lk_0 - lk_inf)*(dt*(i-1)/t_bc);
        
    else
        lk = lk_inf;
    end
    
    ks = 1/2 * sqrt(3) * Ys * ts * lk.^2;
    %thetaBar = sqrt(ks ./ kb(2) * (lambda-1)^2);
    viscLen = mean(lk);
    
    
    [q,v] = BilayerUpdate(q,v);
    
    figure(2)
    clf;
    hold on;
    x = q(1:3:end);
    y = q(2:3:end);
    z = q(3:3:end);
    plot3(x,y,z,'ro');
    
end